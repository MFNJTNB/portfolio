#include <iostream>
#include <vector>
#include <stdexcept>
#include "dijkstra.h"


void DijkstraSolver::scan(Node* node){
    for(auto& edge: node->getEdges()){
        Node* nbor = edge.getDestination();
        
        // get the total cost to get to destination node through this edge
        int candVal = node->getValue() + costFunc(edge);
        
        // compare compounded cost to destination node with lowest cost so far
        if( candVal < nbor->getValue()){
            // cost through this node is lower
            nbor->setValue(candVal);
            nbor->setParent(node);
        }
        
        if(! nbor->getVisited()){
            open.add(nbor);
        }
    }
    node->setVisited(true);
}

void DijkstraSolver::solve(Node* node){
    if( node == nullptr){
        //std::cout << "nullptr argument to solve" << std::endl;
        //throw std::invalid_argument("nullptr argument to solve");
        std::cout<<"bad argument, DijkstraSolver::solve() terminated"<<std::endl;
        return;
    }
    node->setParent(nullptr);
    node->setValue(0);
    open.clear();
    open.add(node);
    while(! open.isEmpty()){
        scan(open.removeMin());
    }
    return;
}


void printPath(Node* destination, std::ostream& os){
    Node* backtracker;
    backtracker = destination;
    std::vector<Node*> pathVector;
    pathVector.push_back(backtracker);
    
    // parent is nullptr means we have arrived at the origin node
    while( (backtracker = backtracker->getParent()) != nullptr){
        pathVector.push_back(backtracker);
    }

    // reverse iterate over pathVector
    for(auto it = pathVector.rbegin(); it != pathVector.rend(); ++it){
        os << (*it)->getName() << " ";
    }
    os << destination->getValue() << std::endl;
}
