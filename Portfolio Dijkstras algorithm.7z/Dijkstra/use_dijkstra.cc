#include <iostream>
#include <fstream>

#include "dijkstra.h"
#include "graph.h"

using std::cout;
using std::endl;

int main(){
    cout << "this is an example usage of the dijkstraSolver class" << endl;
    cout << " - check the source file :-)" << endl;
    // graph data in a .tx file, with one edge per line.
    std::ifstream inStrm("graf.txt");
    
    // a Graph object encapsulates nodes and can initilize from a stream ref.
    Graph g(inStrm);
    
    // the algorithm calculates cost to get to a node as the sum of return
    // values from cost function calculated for a path in the node
    // default argument uses a cost function that looks at the length attribute
    // of an edge
    DijkstraSolver ds;
    
    // to control how cost is calculated, construct DijkstraSolver with a single
    // callable argument int costFunc(Edge& edge)
    // The following example is a lambda which makes the algirithm minimize
    // number of nodes visited by considering all edges as the same cost 1.
    DijkstraSolver dsMinNodes{ [](Edge& ){return 1;} };
    
    ds.solve( g.find("Lund") );
    
    // printPath(Node* N) prints the name of the nodes in the shortest path from
    // origin to N, followed by the total cost. all items separated with spaces.
    printPath(g.find("Veberod"), std::cout);
    
    // The result is written into the nodes themselves o if you want to print
    // or otherwise save paths, this has to be done between consecuive calls to
    // DijkstraSolver::solve()
    // before a new solve call the graph needs to be reset with graph.reset()
    g.reset();
    dsMinNodes.solve( g.find("Lund"));
    
    printPath(g.find("Veberod"), std::cout);
    
    return 0;
}
