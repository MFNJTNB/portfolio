#ifndef GRAPH_H
#define GRAPH_H

#include <memory>
#include <istream>
#include "node.h"


class Graph{
public:
    Graph(){}
    Graph(std::istream& in);
    void addNode(const std::string& name);
    Node* find( const std::string& name);
    void reset();
    void printNames();
private:
    std::vector<std::unique_ptr<Node>> nodes;
};

#endif
