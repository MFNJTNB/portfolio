#include <string>
#include <algorithm>
#include <iostream>
//#include <ctype.h>

#include "graph.h"
using std::cout;
using std::endl;

std::string stringToLower(const std::string& input)
{
    std::string output = input;
    std::transform(output.begin(), output.end(), output.begin(), ::tolower);
    return output;
}

Graph::Graph(std::istream& in){
    std::string from;
    std::string to;
    int len;
    
    while(in.good()){
        std::getline(in, from, ':');
        in >> len;
        in.ignore(1,' ');
        std::getline(in, to);
    
        if(!from.empty() & !to.empty()){
    
    
            //cout<< "debug:" << from << "|" << to << "|" << len << endl;
            
            // addNode is safe when trying to add the same name more than once
            addNode(from); 
            addNode(to);
    
            find(from)->addEdge(find(to), len);
        }
    }
}

void Graph::addNode(const std::string& name){
    if(find(name) == nullptr){
        std::unique_ptr<Node> node_ptr(new Node(name));
        nodes.push_back(std::move(node_ptr));
    }

}


Node* Graph::find( const std::string& name){
    //~ struct isname{
        //~ isname(const std::string& n): name(n){}
        //~ bool operator()(Node* node){
            //~ return name == node->getName();
        //~ }
        //~ std::string name;
    //~ };
    //~ return std::find( nodes.begin(), nodes.end(), isname(name))->get();
    
    std::string lowerName = stringToLower(name);
    for(auto& i : nodes){
        if(stringToLower(i->getName()) == lowerName){
            return i.get();
        }
    }
    //std::cout << "No node with name: " << name << ", returning nullptr" << endl;
    return nullptr;
}

void Graph::reset(){
    for(auto& n: nodes){
        n->setValue(Node::max_value);
        n->setParent(nullptr);
        n->setVisited(false);
    }
}

void Graph::printNames(){
    std::cout << "--" << std::endl;
    for(auto& node: nodes){
        std::cout << node->getName() << endl;
    }
    std::cout << "--" << std::endl;
}
    
    
