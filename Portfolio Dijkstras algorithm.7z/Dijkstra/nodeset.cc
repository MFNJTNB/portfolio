//#include <set>
//#include "node.h"
#include "nodeset.h"

Node* NodeSet::removeMin(){
    if(! isEmpty()){
        Node* temp = *nodes.begin();
        nodes.erase(nodes.begin());
        return temp;
    }else{
        return nullptr;
    }
}
    
void NodeSet::add(Node* node){
    nodes.insert(node);
    }
