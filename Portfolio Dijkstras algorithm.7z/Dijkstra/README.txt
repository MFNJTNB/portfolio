A handin projekt for C++ course at LTH Helsingborg.
Includes tools, unittests and example usage for evaluating shortest path in a graph with dijkstras algorithm.

Built and tested with MinGw on windows 10.

NOTE: The makefile sets the following linker flag in order for minGW produced executables to work properly:
-static-libstdc++

build user program with:
make use_dijkstra

build and run tests with:
make text