#include<string>
#include<vector>

#include "node.h"
#include "edge.h"

void Node::addEdge(Node* node, int len){
    edges.push_back(Edge(node, len));
}
