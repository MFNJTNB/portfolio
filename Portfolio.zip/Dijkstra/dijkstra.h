#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include <functional>
#include <iostream>
#include "node.h"
#include "edge.h"
#include "nodeset.h"

class DijkstraSolver{
public:
    //DijkstraSolver() = delete;
    DijkstraSolver(): costFunc{onEdgeLength} {};
    DijkstraSolver( std::function<int(Edge&)> cf ): costFunc{cf} {};
    void solve(Node* node);
    Node* getMin(){return open.removeMin();}
    static int onEdgeLength(Edge& e){return e.getLength();};
    static int onEdgeCount(Edge&){return 1;};
private:
    void scan(Node* node);
    NodeSet open;
    std::function<int(Edge&)> costFunc;

};


void printPath(Node* destination, std::ostream& os);

#endif
