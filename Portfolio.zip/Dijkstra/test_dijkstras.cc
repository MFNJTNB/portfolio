#include <vector>
#include <string>
#include <cassert>
#include <iostream>
#include <fstream>

#include "dijkstra.h"
#include "node.h"
#include "edge.h"
#include "nodeset.h"
#include "graph.h"

using std::cout;
using std::endl;
using std::vector;

void test_node_basic(){
    
    //testing Node
    Node n{"test"};
    if( n.getValue() != Node::max_value){
        cout << "Node default constructed with wrong value" << endl;
    }
    Node m{"test2"};

    n.setValue(15);
    m.setValue(25);

    if(n.getName() != "test"){
        cout << "getName() does not work" << endl;
    }

    if(n.getValue() != 15){
        cout << "getValue() or setValue() does not work" << endl;
    }

    if(m.getValue() != 25){
        cout << "getValue() or setValue() does not work" << endl;
    }

    //testar Edge
    Edge e{&m, 12};

    if(e.getDestination() != &m){
        cout << "getDestination() does not work" << endl;
    }

    if(e.getLength() != 12){
        cout << "getLength() does not work" << endl;
    }

    n.addEdge(&m, 6);              //lägg till funktionalitet för test av funktionen addEdge
    
    //const vector<Edge>& edges = n.getEdges();

    if( n.getEdges()[0].getDestination() != &m ){
        cout << "getEdges() does not work" << endl;
    }
}
Node* find_and_test(const std::string& s, Graph& g)
{
    Node * n = g.find(s);
    assert(n != nullptr);
    assert(n->getName() == s);
    assert(n->getValue() == Node::max_value);
    return n;
}
void test_graph()
{
    Graph g{};

    g.addNode("Lund");
    g.addNode("Dalby");
    g.addNode("Sodra Sandby");
    g.addNode("Torna Hallestad");
    g.addNode("Flyinge");
    g.addNode("Veberod");
    
    if( g.find("Lund")->getName() != "Lund"){
        cout << "Graph.find(strig) bad return" << endl;
    }

    auto n_lund = find_and_test("Lund", g);
    find_and_test("Dalby", g);
    find_and_test("Sodra Sandby", g);
    find_and_test("Veberod", g);
    find_and_test("Torna Hallestad", g);
    auto n_flyinge = find_and_test("Flyinge", g);

    n_lund->setValue(17);
    auto n2 = g.find("Lund");
    assert(n2->getValue()==17);

    auto n3 = g.find("Flyinge");
    n_flyinge->setValue(42);
    assert(n3->getValue()==42);

    //~ g.resetVals();
    //~ for(auto it = g.begin(); it != g.end(); ++it){
        //~ assert((*it)->getValue() == Node::max_value);
    //~ }
}


void test_dijkstra_scan(){
    
    Node n1("start");
    Node n2("n2");
    Node n3("n3");
    Node n4("n4");
    
    n1.addEdge(&n2, 5);
    n1.addEdge(&n3, 10);
    n1.addEdge(&n4, 15);
    
    n2.addEdge(&n3, 2);
    
    //~ DijkstraSolver ds;
    //~ ds.scan(&n1);
    //~ if( ds.getMin() != &n2){
        //~ cout << "Dijkstrasolver.scan bad reult" << endl;
    //~ }
    
}

void test_dijkstra_full(){
    
    Node n0("start");
    Node n1("n1");
    Node n2("n2");
    Node n3("n3");
    Node n4("n4");
    
    n0.addEdge(&n1, 5);
    n0.addEdge(&n2, 10);
    n0.addEdge(&n3, 15);
    n0.addEdge(&n4, 20);
    
    n1.addEdge(&n2, 2);
    n2.addEdge(&n4, 2);
    n4.addEdge(&n1, 1);
    
    
    DijkstraSolver ds;
    ds.solve(&n0);
    
    if(n0.getValue() != 0){
        cout << "start node doesnt have value 0" << endl;
    }
    
    if( n4.getValue() != 9){
        cout << n3.getValue() << endl;
        cout << "Dijkstrasolver.solve() bad result" << endl;
    }
    if( n1.getValue() != 5) cout << "n1 bad value" << endl;
    
    if( n4.getValue() != 9) cout << "n4 bad value" << endl;
    
    // check path through parent nodes
    if( n4.getParent() != &n2) cout << "n4 bad parent" << endl;
    if( n2.getParent() != &n1) cout << "n2 bad parent" << endl;
    if( n1.getParent() != &n0) cout << "n1 bad parent" << endl;
}
    
void test_nodeset(){
    Node n1("n1");
    Node n2("n2");
    Node n3("n3");
    
    n1.setValue(10);
    n2.setValue(20);
    n3.setValue(5);
    
    // construct NodeSet
    NodeSet ns;
    if(!ns.isEmpty())cout<<"NodeSet.isEmpty() should be empy here"<<endl;

    ns.add(&n1);
    if(ns.isEmpty())cout<<"NodeSet.isEmpty() shuld not be empty here"<<endl;
    
    if(ns.removeMin() != &n1){
        cout<< "NodeSet.removeMin() with 1 elem: bad return" << endl;
    }
    if(!ns.isEmpty()){
        cout<<"removeMin() should be empty after removeMin()"<<endl;
    }
    
    ns.add(&n2);
    ns.add(&n3);
    
    if( ns.removeMin() != &n3){
        cout << "removeMin() with multiple elem: bad return" <<endl;
    }
    
    NodeSet ns2;
    ns2.add(&n1);
    ns2.add(&n1);
    ns2.add(&n1);
    
    if(ns.getSize() != 1){
        cout<<"NodeSet doesnt handle multiple add of same item as set"<<endl;
    }
}
void test_bad_input(){
    std::ifstream graphStream{"graf.txt"};
    Graph g(graphStream);
    if(g.find("non_existent_name") !=  nullptr){
        cout << "error on invalid input to Graph:find" << endl;
    }
    
    DijkstraSolver ds;
    cout << "testing bad input to graph" << endl;
    cout << "expecting error message - bad argument:" << endl;
    ds.solve(g.find("non_existent_name"));
    graphStream.close();
}

void test_graph_file(){
    std::ifstream graphStream{"graf.txt"};
    Graph g(graphStream);
    if(g.find("Lund")->getName() != "Lund"){
        cout << "error on graph from file" << endl;
    }
    graphStream.close();
    
    DijkstraSolver ds( [](Edge& ){return 1;} );
    ds.solve(g.find("Lund"));
    //printPath(g.find("Veberod"), cout);
    if( g.find("Veberod")->getValue() != 2){
        cout<<"wrong result with lambda function: equal cost per edge"<<endl;
    }
    
    DijkstraSolver ds2( DijkstraSolver::onEdgeCount );
    if( g.find("Veberod")->getValue() != 2){
        cout<<"wrong result with builtin function: equal cost per edge"<<endl;
    }
    
    g.reset();
    DijkstraSolver ds3;
    ds3.solve(g.find("Lund"));
    if( g.find("Veberod")->getValue() != 23){
        cout<<"wrong result with default function: diff cost per edge"<<endl;
    }
    //printPath(g.find("veberod"), cout);
}

int main()
{
    test_graph_file();
    test_node_basic();
    test_nodeset();
    test_graph();
    test_bad_input();
    
    // dijkstraSolver::scan can no longer be tested on its own since it's now
    // private and used only by DijkstraSolver::solve
    //test_dijkstra_scan();
    test_dijkstra_full();
    //test_graph_file();
    return 0;
}
