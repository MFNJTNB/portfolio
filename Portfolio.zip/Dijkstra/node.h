#ifndef NODE_H
#define NODE_H

#include <vector>
#include <string>
#include <limits>

#include "edge.h"

//class Edge;
class Node{
public:
    Node(const std::string& name):
        name{name},
        value{max_value},
        parent{nullptr},
        visited{false}
        {}
    std::string getName(){return name;}
    std::vector<Edge>& getEdges(){return edges; }
    void addEdge(Node* n, int len);
    int getValue()const {return value;}
    void setValue(int val){value = val;}
    static const int max_value{std::numeric_limits<int>::max()};
    Node* getParent(){return parent;}
    void setParent(Node * par){parent = par;}
    void setVisited(bool v){ visited = v ;}
    bool getVisited(){ return visited;}

private:
    std::string name;
    int value;
    std::vector<Edge> edges;
    Node* parent;
    bool visited;
};

#endif
