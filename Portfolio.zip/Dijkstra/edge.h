#ifndef EDGE_H
#define EDGE_H

//#include "node.h"
class Node;

class Edge{
public:
    Edge() = delete;
    Edge(Node* dest, int len): destination{dest}, length{len} {}
    int getLength(){return length;}
    Node* getDestination(){return destination;}
private:
    Node* destination;
    int length;
};
    
#endif
