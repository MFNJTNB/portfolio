#include <vector>
#include <string>

#include "node.h"
#inlude "edge.h"

void test_node_basic(){
    // tests that instantiation an getting name of a node object is possible
    Node n{"Lund"};
    assert(n.getName() == "Lund");
}


int main()
{
    test_node_basic
    return 0;
}
