#ifndef NODESET_H
#define NODESET_H

#include <set>
#include "node.h"

struct nodeComp{
    bool operator()(const Node* a, const Node* b)const {
        // compare node objects on numerical attribute value
        return a->getValue() < b->getValue();
    }
};


class NodeSet{
public:
    NodeSet(){}
    void add(Node* node);
    bool isEmpty(){return nodes.empty();}
    Node* removeMin();
    int getSize(){return static_cast<int>(nodes.size());}
    void clear(){nodes.clear();}
private:
    std::set<Node*, nodeComp> nodes;
};


#endif
